
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `fanfiction_authorfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fanfiction_authorfields` (
  `field_id` int NOT NULL AUTO_INCREMENT,
  `field_type` tinyint NOT NULL DEFAULT '0',
  `field_name` varchar(30) COLLATE utf8mb4_general_ci NOT NULL DEFAULT ' ',
  `field_title` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT ' ',
  `field_options` text COLLATE utf8mb4_general_ci,
  `field_code_in` text COLLATE utf8mb4_general_ci,
  `field_code_out` text COLLATE utf8mb4_general_ci,
  `field_on` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`field_id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fanfiction_authorfields` WRITE;
/*!40000 ALTER TABLE `fanfiction_authorfields` DISABLE KEYS */;
INSERT INTO `fanfiction_authorfields` VALUES (1,4,'lj','Live Journal','http://{info}.livejournal.com','','',0);
INSERT INTO `fanfiction_authorfields` VALUES (2,1,'website','Web Site','','','',1);
INSERT INTO `fanfiction_authorfields` VALUES (3,5,'AOL','AIM','','$output .= \"<div><label for=\'AOL\'>\".$field[\'field_title\'].\":</label><INPUT type=\'text\' class=\'textbox\'  name=\'af_\".$field[\'field_name\'].\"\' maxlength=\'40\' value=\'\".(!empty($user[\'af_\'.$field[\'field_id\']]) ? $user[\'af_\'.$field[\'field_id\']] : \"\").\"\' size=\'20\'></div>\";','$thisfield = \"<img src=\\\"http://big.oscar.aol.com/\".$field[\'info\'].\"?on_url=$url/images/aim.gif&off_url=$url/images/aim.gif\\\"> <a href=\\\"aim:goim?{aol}ScreenName=\".$field[\'info\'].\"\\\">\".format_email($field[\'info\']).\"</a>\";',1);
INSERT INTO `fanfiction_authorfields` VALUES (4,5,'ICQ','ICQ','','$output .= \"<div><label for=\'AOL\'>\".$field[\'field_title\'].\":</label><INPUT type=\'text\' class=\'textbox\'  name=\'af_\".$field[\'field_name\'].\"\' maxlength=\'40\' value=\'\".(!empty($user[\'af_\'.$field[\'field_id\']]) ? $user[\'af_\'.$field[\'field_id\']] : \"\").\"\' size=\'20\'></div>\";','$thisfield = \"<img src=\\\"http://status.icq.com/online.gif?icq=\".$field[\'info\'].\"&img=5\\\"> \".$field[\'info\'];',1);
INSERT INTO `fanfiction_authorfields` VALUES (5,5,'MSN','MSN IM','','$output .= \"<div><label for=\'AOL\'>\".$field[\'field_title\'].\":</label><INPUT type=\'text\' class=\'textbox\'  name=\'af_\".$field[\'field_name\'].\"\' maxlength=\'40\' value=\'\".(!empty($user[\'af_\'.$field[\'field_id\']]) ? $user[\'af_\'.$field[\'field_id\']] : \"\").\"\' size=\'20\'></div>\";','$thisfield = \"<img src=\\\"images/msntalk.gif\\\" alt=\\\"\"._MSN.\"\\\"> \".format_email($field[\'info\']);',1);
INSERT INTO `fanfiction_authorfields` VALUES (6,5,'Yahoo','Yahoo IM','','$output .= \"<div><label for=\'AOL\'>\".$field[\'field_title\'].\":</label><INPUT type=\'text\' class=\'textbox\'  name=\'af_\".$field[\'field_name\'].\"\' maxlength=\'40\' value=\'\".(!empty($user[\'af_\'.$field[\'field_id\']]) ? $user[\'af_\'.$field[\'field_id\']] : \"\").\"\' size=\'20\'></div>\";','$thisfield = \"<a href=\\\"http://edit.yahoo.com/config/send_webmesg?.target=\".$field[\'info\'].\"&.src=pg\\\"><img border=\'0\' src=\\\"http://opi.yahoo.com/online?u=\".$field[\'info\'].\"&m=g&t=1\\\"> \".format_email($field[\'info\']).\"</a>\";',1);
INSERT INTO `fanfiction_authorfields` VALUES (7,4,'da','Deviant Art','http://{info}.deviantart.com','','',0);
INSERT INTO `fanfiction_authorfields` VALUES (8,3,'betareader','Beta-reader','','','',1);
INSERT INTO `fanfiction_authorfields` VALUES (9,4,'dj','DeadJournal','http://{info}.deadjournal.com/','','',0);
INSERT INTO `fanfiction_authorfields` VALUES (10,4,'xanga','Xanga','http://www.xanga.com/{info}','','',0);
INSERT INTO `fanfiction_authorfields` VALUES (11,2,'gender','Gender','male|#|female|#|undisclosed','','',0);
INSERT INTO `fanfiction_authorfields` VALUES (12,4,'myspace','MySpace','http://www.myspace.com/{info}','','',0);
/*!40000 ALTER TABLE `fanfiction_authorfields` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fanfiction_authorinfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fanfiction_authorinfo` (
  `uid` int NOT NULL DEFAULT '0',
  `field` int NOT NULL DEFAULT '0',
  `info` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT ' ',
  PRIMARY KEY (`uid`,`field`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fanfiction_authorinfo` WRITE;
/*!40000 ALTER TABLE `fanfiction_authorinfo` DISABLE KEYS */;
/*!40000 ALTER TABLE `fanfiction_authorinfo` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fanfiction_authorprefs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fanfiction_authorprefs` (
  `uid` int NOT NULL DEFAULT '0',
  `newreviews` tinyint(1) NOT NULL DEFAULT '0',
  `newrespond` tinyint(1) NOT NULL DEFAULT '0',
  `ageconsent` tinyint(1) NOT NULL DEFAULT '0',
  `alertson` tinyint(1) NOT NULL DEFAULT '0',
  `tinyMCE` tinyint(1) NOT NULL DEFAULT '0',
  `sortby` tinyint(1) NOT NULL DEFAULT '0',
  `storyindex` tinyint(1) NOT NULL DEFAULT '0',
  `validated` tinyint(1) NOT NULL DEFAULT '0',
  `userskin` varchar(60) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'default',
  `level` tinyint(1) NOT NULL DEFAULT '0',
  `categories` varchar(200) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0',
  `contact` tinyint(1) NOT NULL DEFAULT '0',
  `stories` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fanfiction_authorprefs` WRITE;
/*!40000 ALTER TABLE `fanfiction_authorprefs` DISABLE KEYS */;
INSERT INTO `fanfiction_authorprefs` VALUES (1,0,0,0,0,0,0,0,0,'default',1,'0',0,0);
INSERT INTO `fanfiction_authorprefs` VALUES (10,0,0,0,0,0,0,0,0,'default',0,'0',0,0);
INSERT INTO `fanfiction_authorprefs` VALUES (11,0,0,0,0,0,0,0,0,'default',0,'0',0,0);
INSERT INTO `fanfiction_authorprefs` VALUES (12,0,0,0,0,0,0,0,0,'default',0,'0',0,0);
/*!40000 ALTER TABLE `fanfiction_authorprefs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fanfiction_authors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fanfiction_authors` (
  `uid` int NOT NULL AUTO_INCREMENT,
  `penname` varchar(200) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `realname` varchar(200) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `email` varchar(200) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `bio` text COLLATE utf8mb4_general_ci,
  `image` varchar(200) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `admincreated` char(1) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0',
  `password` varchar(40) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`uid`),
  KEY `penname` (`penname`),
  KEY `admincreated` (`admincreated`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fanfiction_authors` WRITE;
/*!40000 ALTER TABLE `fanfiction_authors` DISABLE KEYS */;
INSERT INTO `fanfiction_authors` VALUES (1,'FixtureAdmin','','admin@fixture.local',NULL,'','2026-10-14 13:43:17','0','2d1b23feb1c352a4b96201ebd0278acd');
INSERT INTO `fanfiction_authors` VALUES (10,'AuthorOwner','Owner','owner@fixture.local','<p>Bio.</p>','','2026-10-14 13:43:17','0','d040031d9323a4a6ef74b87b34b3e7ff');
INSERT INTO `fanfiction_authors` VALUES (11,'CoAuthor','Co','co@fixture.local','<p>Bio.</p>','','2026-10-14 13:43:17','0','3fad3a0d49b6106c9e9f91367d4751d9');
INSERT INTO `fanfiction_authors` VALUES (12,'OtherMember','Other','other@fixture.local','<p>Bio.</p>','','2026-10-14 13:43:17','0','f32c359cb33c42bc758c648f681f7d95');
/*!40000 ALTER TABLE `fanfiction_authors` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fanfiction_blocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fanfiction_blocks` (
  `block_id` int NOT NULL AUTO_INCREMENT,
  `block_name` varchar(30) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `block_title` varchar(150) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `block_file` varchar(200) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `block_status` tinyint(1) NOT NULL DEFAULT '0',
  `block_variables` text COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`block_id`),
  KEY `block_name` (`block_name`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fanfiction_blocks` WRITE;
/*!40000 ALTER TABLE `fanfiction_blocks` DISABLE KEYS */;
INSERT INTO `fanfiction_blocks` VALUES (1,'categories','Categories','categories/categories.php',1,'');
INSERT INTO `fanfiction_blocks` VALUES (2,'featured','Featured Stories','featured/featured.php',1,'');
INSERT INTO `fanfiction_blocks` VALUES (3,'info','Site Info','info/info.php',2,'');
INSERT INTO `fanfiction_blocks` VALUES (4,'login','Log In','login/login.php',1,'');
INSERT INTO `fanfiction_blocks` VALUES (5,'menu','Main Menu','menu/menu.php',1,'');
INSERT INTO `fanfiction_blocks` VALUES (6,'random','Random Story','random/random.php',2,'');
INSERT INTO `fanfiction_blocks` VALUES (7,'recent','Most Recent','recent/recent.php',2,'a:1:{s:3:\"num\";s:1:\"1\";}');
INSERT INTO `fanfiction_blocks` VALUES (8,'skinchange','Skin Change','skinchange/skinchange.php',1,'');
INSERT INTO `fanfiction_blocks` VALUES (9,'news','Site News','news/news.php',1,'a:1:{s:3:\"num\";s:1:\"1\";}');
/*!40000 ALTER TABLE `fanfiction_blocks` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fanfiction_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fanfiction_categories` (
  `catid` int NOT NULL AUTO_INCREMENT,
  `parentcatid` int NOT NULL DEFAULT '-1',
  `category` varchar(60) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `description` text COLLATE utf8mb4_general_ci NOT NULL,
  `image` varchar(100) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `locked` char(1) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0',
  `leveldown` tinyint NOT NULL DEFAULT '0',
  `displayorder` int NOT NULL DEFAULT '0',
  `numitems` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`catid`),
  KEY `byparent` (`parentcatid`,`displayorder`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fanfiction_categories` WRITE;
/*!40000 ALTER TABLE `fanfiction_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `fanfiction_categories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fanfiction_chapters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fanfiction_chapters` (
  `chapid` int NOT NULL AUTO_INCREMENT,
  `title` varchar(250) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `inorder` int NOT NULL DEFAULT '0',
  `notes` text COLLATE utf8mb4_general_ci,
  `storytext` text COLLATE utf8mb4_general_ci,
  `endnotes` text COLLATE utf8mb4_general_ci,
  `validated` char(1) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0',
  `wordcount` int NOT NULL DEFAULT '0',
  `rating` tinyint NOT NULL DEFAULT '0',
  `reviews` smallint NOT NULL DEFAULT '0',
  `sid` int NOT NULL DEFAULT '0',
  `uid` int NOT NULL DEFAULT '0',
  `count` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`chapid`),
  KEY `sid` (`sid`),
  KEY `uid` (`uid`),
  KEY `inorder` (`inorder`),
  KEY `title` (`title`),
  KEY `validated` (`validated`),
  KEY `forstoryblock` (`sid`,`validated`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fanfiction_chapters` WRITE;
/*!40000 ALTER TABLE `fanfiction_chapters` DISABLE KEYS */;
INSERT INTO `fanfiction_chapters` VALUES (1,'Chapter One',1,'','','','1',8,0,0,1,10,0);
INSERT INTO `fanfiction_chapters` VALUES (2,'Hidden Chapter',1,'','','','0',8,0,0,2,10,0);
/*!40000 ALTER TABLE `fanfiction_chapters` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fanfiction_characters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fanfiction_characters` (
  `charid` int NOT NULL AUTO_INCREMENT,
  `catid` int NOT NULL DEFAULT '0',
  `charname` varchar(60) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `bio` text COLLATE utf8mb4_general_ci NOT NULL,
  `image` varchar(200) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`charid`),
  KEY `catid` (`catid`),
  KEY `charname` (`charname`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fanfiction_characters` WRITE;
/*!40000 ALTER TABLE `fanfiction_characters` DISABLE KEYS */;
/*!40000 ALTER TABLE `fanfiction_characters` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fanfiction_classes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fanfiction_classes` (
  `class_id` int NOT NULL AUTO_INCREMENT,
  `class_type` int NOT NULL DEFAULT '0',
  `class_name` varchar(100) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`class_id`),
  KEY `byname` (`class_type`,`class_name`,`class_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fanfiction_classes` WRITE;
/*!40000 ALTER TABLE `fanfiction_classes` DISABLE KEYS */;
/*!40000 ALTER TABLE `fanfiction_classes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fanfiction_classtypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fanfiction_classtypes` (
  `classtype_id` int NOT NULL AUTO_INCREMENT,
  `classtype_name` varchar(50) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `classtype_title` varchar(50) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`classtype_id`),
  UNIQUE KEY `classtype_name` (`classtype_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fanfiction_classtypes` WRITE;
/*!40000 ALTER TABLE `fanfiction_classtypes` DISABLE KEYS */;
/*!40000 ALTER TABLE `fanfiction_classtypes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fanfiction_coauthors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fanfiction_coauthors` (
  `sid` int NOT NULL DEFAULT '0',
  `uid` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`sid`,`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fanfiction_coauthors` WRITE;
/*!40000 ALTER TABLE `fanfiction_coauthors` DISABLE KEYS */;
INSERT INTO `fanfiction_coauthors` VALUES (2,11);
/*!40000 ALTER TABLE `fanfiction_coauthors` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fanfiction_codeblocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fanfiction_codeblocks` (
  `code_id` int NOT NULL AUTO_INCREMENT,
  `code_text` text COLLATE utf8mb4_general_ci NOT NULL,
  `code_type` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `code_module` varchar(60) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`code_id`),
  KEY `code_type` (`code_type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fanfiction_codeblocks` WRITE;
/*!40000 ALTER TABLE `fanfiction_codeblocks` DISABLE KEYS */;
/*!40000 ALTER TABLE `fanfiction_codeblocks` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fanfiction_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fanfiction_comments` (
  `cid` int NOT NULL AUTO_INCREMENT,
  `nid` int NOT NULL DEFAULT '0',
  `uid` int NOT NULL DEFAULT '0',
  `comment` text COLLATE utf8mb4_general_ci NOT NULL,
  `time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`cid`),
  KEY `commentlist` (`nid`,`time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fanfiction_comments` WRITE;
/*!40000 ALTER TABLE `fanfiction_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `fanfiction_comments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fanfiction_favorites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fanfiction_favorites` (
  `uid` int NOT NULL DEFAULT '0',
  `item` int NOT NULL DEFAULT '0',
  `type` char(2) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `comments` text COLLATE utf8mb4_general_ci NOT NULL,
  UNIQUE KEY `byitem` (`item`,`type`,`uid`),
  UNIQUE KEY `byuid` (`uid`,`type`,`item`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fanfiction_favorites` WRITE;
/*!40000 ALTER TABLE `fanfiction_favorites` DISABLE KEYS */;
/*!40000 ALTER TABLE `fanfiction_favorites` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fanfiction_inseries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fanfiction_inseries` (
  `seriesid` int NOT NULL DEFAULT '0',
  `sid` int NOT NULL DEFAULT '0',
  `subseriesid` int NOT NULL DEFAULT '0',
  `confirmed` int NOT NULL DEFAULT '0',
  `inorder` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`sid`,`seriesid`,`subseriesid`),
  KEY `seriesid` (`seriesid`,`inorder`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fanfiction_inseries` WRITE;
/*!40000 ALTER TABLE `fanfiction_inseries` DISABLE KEYS */;
/*!40000 ALTER TABLE `fanfiction_inseries` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fanfiction_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fanfiction_log` (
  `log_id` int NOT NULL AUTO_INCREMENT,
  `log_action` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `log_uid` int NOT NULL,
  `log_ip` int unsigned DEFAULT NULL,
  `log_timestamp` timestamp NOT NULL,
  `log_type` varchar(2) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`log_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fanfiction_log` WRITE;
/*!40000 ALTER TABLE `fanfiction_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `fanfiction_log` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fanfiction_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fanfiction_messages` (
  `message_id` int NOT NULL AUTO_INCREMENT,
  `message_name` varchar(50) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `message_title` varchar(200) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `message_text` text COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`message_id`),
  KEY `message_name` (`message_name`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fanfiction_messages` WRITE;
/*!40000 ALTER TABLE `fanfiction_messages` DISABLE KEYS */;
INSERT INTO `fanfiction_messages` VALUES (1,'welcome','','This is your welcome message. It appears on the index page. Include it in your .tpl files with {welcome}.');
INSERT INTO `fanfiction_messages` VALUES (2,'copyright','','This is your sample copyright footer.  Include it in your footer.tpl with <b>{footer}</b><br />\r\n<u>Disclaimer:</u>  All publicly recognizable characters, settings, etc. are the property of their respective owners.  The original characters and plot are the property of the author.  No money is being made from this work.  No copyright infringement is intended.\r\n');
INSERT INTO `fanfiction_messages` VALUES (3,'help','Help','<h3>FAQ</h3><p><strong>I forgot my password!&nbsp; What do I do now?</strong></p><p>To recover a lost password, <a href=\"user.php?action=lostpassword\">click here</a> and enter the e-mail address with which you registered.&nbsp; Your password will be sent to you shortly.</p><p><strong>What kinds of stories are allowed?</strong></p><p>See our <a href=\"submission.php\">Submission Rules.</a></p><p><strong>How do I contact the site administrators?</strong></p><p>You can e-mail us via our <a href=\"contact.php\">contact form.</a></p><p><strong>How do I submit stories?</strong></p><p>If you have not already done so, please <a href=\"user.php?action=newaccount\">register for an account</a>. Once you\'ve logged in, click on <a href=\"user.php\">Account Information</a> and choose <a href=\"stories.php?action=newstory\">Add Story</a>.&nbsp; The form presented there will allow you to submit your story.</p><p><strong>What are the ratings used on the site?</strong></p><p>We use the ratings system from <a href=\"http://www.fictionratings.com/\">www.fictionratings.com</a>.</p><p><strong>What are the story classifications?</strong></p><p>Stories are classified by categories, genres, and warnings.</p>');
INSERT INTO `fanfiction_messages` VALUES (4,'nothankyou','Submission Rejection','Your recent submission of \"{storytitle} : {chaptertitle}\" to {sitename} did not meet our requirements for submission.  Please review our {rules}.<br /><br />\r\n\r\n{adminname}');
INSERT INTO `fanfiction_messages` VALUES (5,'printercopyright','','<u>Disclaimer:</u> All publicly recognizable characters and settings are the property of their respective owners. The original characters and plot are the property of the author. No money is being made from this work. No copyright infringement is intended.');
INSERT INTO `fanfiction_messages` VALUES (6,'rules','Submission Rules','<p align=\"center\"><strong>Submission Rules</strong></p>\r\n<ol>\r\n  <li>All submissions must be accompanied by a complete disclaimer. If a \r\n  suitable disclaimer is not included, the site administrators reserve the right \r\n  to add a disclaimer.&nbsp; Repeat offenders may be subject to further action \r\n  up to and including removal of stories and account.\r\n<div class=\"tblborder\" style=\"width: 400px; margin: 1em auto;\">\r\n<div style=\"background: #000; color: #FFF; padding: 5px; text-align: center; font-weight: bold;\">Sample Disclaimer</div>\r\n<div class=\"tblborder\" style=\"padding: 5px;\"><span style=\"text-decoration: underline;\">Disclaimer:</span>  All publicly recognizable characters, settings, etc. are the property of their respective owners.  The original characters and plot are the property of the author.&nbsp; \r\n        The author is in no way associated with the owners, creators, or producers of any media franchise.&nbsp;  No copyright infringement is intended.</div>\r\n  </div>\r\n  </li>\r\n  <li>Stories must be submitted to the proper category. &nbsp;If there is an appropriate sub-category, <strong>DO NOT</strong> add your story to the main category.&nbsp; The submission \r\n  form allows you to choose multiple categories for your story, and we worked very hard to add that functionality for you.&nbsp;&nbsp; <u><strong>So please \r\n  do NOT add your story multiple times!</strong></u></li>\r\n  <li>Titles and summaries must be kid friendly.&nbsp; No exceptions.&nbsp; </li>\r\n  <li>&quot;Please read&quot;, &quot;Untitled&quot;, etc. are not acceptable titles or summaries.</li>\r\n  <li>A number of authors have requested that fans refrain from writing fan \r\n  fiction based on their work.&nbsp; Therefore submissions will not be \r\n  accepted based on the works of P.N. Elrod, Raymond Feist, Terry Goodkind, \r\n  Laurell K. Hamilton, Anne McCaffrey, Robin McKinley, Irene Radford, Anne Rice, \r\n  and Nora Roberts/J.D. Robb.&nbsp; </li>\r\n  <li>Actor/actress stories are not permitted...not even if they\'re visiting an \r\n  alternate reality.</li>\r\n  <li>Correct grammar and spelling are expected of all stories submitted to this \r\n  site.&nbsp; The site administrators are not grammar Nazis.&nbsp; However, the \r\n  site administrators reserve the right to request corrections in submissions \r\n  with a multitude of grammar and/or spelling errors.&nbsp; If such a request is \r\n  ignored, the story will be deleted.</li>\r\n  <li>All stories must be rated correctly and have the appropriate warnings.&nbsp; \r\n  All adult rated stories are expected to have warnings.&nbsp; After all, they \r\n  wouldn\'t have that rating if there wasn\'t something to be warned about!&nbsp; The site administrators recognize \r\n  that there is an audience for these stories, but please respect those who do \r\n  not wish to read them by labeling them appropriately.&nbsp;\r\n  <u><strong>Please note: Stories containing adults having sex with minors are strictly forbidden.</strong></u>&nbsp; </li>\r\n  <li>Stories with multiple chapters should be archived as such and <span style=\"font-weight: bold; text-decoration: underline;\">NEVER</span> as \r\n  separate stories.&nbsp; Upload the first chapter of your story, then go to <a href=\"stories.php?action=viewstories\">Manage Stories</a> in \r\nyour account to add additional chapters.  If you have trouble with this, please contact the site administrator or ask a \r\n  friend to help you.</li>\r\n  <li>As much as possible, spoiler warnings are expected on all stories.  For categories with serialized content, such as series of books or television series, \r\n  spoilers are <strong>mandatory</strong> for the current season and/or most recent part.  An appropriate spoiler warning to place in your summary would be: Spoilers for <u>Star Trek II: The Wrath of Khan.</u> \r\n  <strong>DO NOT</strong> do anything like this: <u>Spoilers for the one where Spock dies.</u></li>\r\n</ol>\r\n  <p>Submissions found to be in violation of these rules may be removed and the \r\n  author\'s account suspended at the discretion of the site administrators and/or \r\n  moderators.&nbsp; The site administrators reserve the right to modify these \r\n  rules as needed.</p>');
INSERT INTO `fanfiction_messages` VALUES (7,'thankyou','{sitename} Submission Acceptance','Thanks for your submission.');
INSERT INTO `fanfiction_messages` VALUES (8,'tos','Terms of Service','This is the Terms of Service for your site.  It will be displayed when a new member registers to the site.');
INSERT INTO `fanfiction_messages` VALUES (9,'maintenance','Site Maintenance','<p style=\"text-align: center;\">This site is currently undergoing maintenance.  Please check back soon.  Thank you.</p>');
/*!40000 ALTER TABLE `fanfiction_messages` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fanfiction_modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fanfiction_modules` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'Test Module',
  `version` varchar(10) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '1.0',
  PRIMARY KEY (`id`),
  KEY `name_version` (`name`,`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fanfiction_modules` WRITE;
/*!40000 ALTER TABLE `fanfiction_modules` DISABLE KEYS */;
/*!40000 ALTER TABLE `fanfiction_modules` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fanfiction_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fanfiction_news` (
  `nid` int NOT NULL AUTO_INCREMENT,
  `author` varchar(60) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `title` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `story` text COLLATE utf8mb4_general_ci NOT NULL,
  `time` datetime DEFAULT NULL,
  `comments` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`nid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fanfiction_news` WRITE;
/*!40000 ALTER TABLE `fanfiction_news` DISABLE KEYS */;
/*!40000 ALTER TABLE `fanfiction_news` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fanfiction_pagelinks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fanfiction_pagelinks` (
  `link_id` int NOT NULL AUTO_INCREMENT,
  `link_name` varchar(50) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `link_text` varchar(100) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `link_key` char(1) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `link_url` varchar(250) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `link_target` char(1) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0',
  `link_access` tinyint NOT NULL DEFAULT '0',
  PRIMARY KEY (`link_id`),
  KEY `link_name` (`link_name`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fanfiction_pagelinks` WRITE;
/*!40000 ALTER TABLE `fanfiction_pagelinks` DISABLE KEYS */;
INSERT INTO `fanfiction_pagelinks` VALUES (1,'home','Home',NULL,'index.php','0',0);
INSERT INTO `fanfiction_pagelinks` VALUES (2,'recent','Most Recent',NULL,'browse.php?type=recent','0',0);
INSERT INTO `fanfiction_pagelinks` VALUES (3,'login','Login',NULL,'user.php?action=login','0',0);
INSERT INTO `fanfiction_pagelinks` VALUES (4,'adminarea','Admin',NULL,'admin.php','0',2);
INSERT INTO `fanfiction_pagelinks` VALUES (5,'logout','Logout',NULL,'user.php?action=logout','0',1);
INSERT INTO `fanfiction_pagelinks` VALUES (6,'featured','Featured Stories',NULL,'browse.php?type=featured','0',0);
INSERT INTO `fanfiction_pagelinks` VALUES (7,'catslink','Categories',NULL,'browse.php?type=categories','0',0);
INSERT INTO `fanfiction_pagelinks` VALUES (8,'members','Members',NULL,'authors.php?action=list','0',0);
INSERT INTO `fanfiction_pagelinks` VALUES (9,'authors','Authors',NULL,'authors.php?list=authors','0',0);
INSERT INTO `fanfiction_pagelinks` VALUES (10,'help','Help',NULL,'viewpage.php?page=help','0',0);
INSERT INTO `fanfiction_pagelinks` VALUES (11,'search','Search',NULL,'search.php','0',0);
INSERT INTO `fanfiction_pagelinks` VALUES (12,'series','Series',NULL,'browse.php?type=series','0',0);
INSERT INTO `fanfiction_pagelinks` VALUES (13,'tens','Top Tens',NULL,'toplists.php','0',0);
INSERT INTO `fanfiction_pagelinks` VALUES (14,'challenges','Challenges',NULL,'modules/challenges/challenges.php','0',0);
INSERT INTO `fanfiction_pagelinks` VALUES (15,'contactus','Contact Us',NULL,'contact.php','0',0);
INSERT INTO `fanfiction_pagelinks` VALUES (16,'rules','Rules',NULL,'viewpage.php?page=rules','0',0);
INSERT INTO `fanfiction_pagelinks` VALUES (17,'tos','Terms of Service',NULL,'viewpage.php?page=tos','0',0);
INSERT INTO `fanfiction_pagelinks` VALUES (18,'rss','<img src=\'images/xml.gif\' alt=\'RSS\' border=\'0\'>',NULL,'rss.php','0',0);
INSERT INTO `fanfiction_pagelinks` VALUES (19,'login','Account Info',NULL,'user.php','0',1);
INSERT INTO `fanfiction_pagelinks` VALUES (20,'titles','Titles',NULL,'browse.php?type=titles','0',0);
INSERT INTO `fanfiction_pagelinks` VALUES (21,'register','Register',NULL,'user.php?action=register','0',0);
INSERT INTO `fanfiction_pagelinks` VALUES (22,'lostpassword','Lost Password',NULL,'user.php?action=lostpassword','0',0);
INSERT INTO `fanfiction_pagelinks` VALUES (23,'newsarchive','News Archive',NULL,'news.php','0',0);
INSERT INTO `fanfiction_pagelinks` VALUES (24,'browse','Browse',NULL,'browse.php','0',0);
INSERT INTO `fanfiction_pagelinks` VALUES (25,'charslink','Characters',NULL,'browse.php?type=characters','0',0);
INSERT INTO `fanfiction_pagelinks` VALUES (26,'ratings','Ratings',NULL,'browse.php?type=ratings','0',0);
/*!40000 ALTER TABLE `fanfiction_pagelinks` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fanfiction_panels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fanfiction_panels` (
  `panel_id` int NOT NULL AUTO_INCREMENT,
  `panel_name` varchar(50) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'unknown',
  `panel_title` varchar(100) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'Unnamed Panel',
  `panel_url` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `panel_level` tinyint NOT NULL DEFAULT '3',
  `panel_order` tinyint NOT NULL DEFAULT '0',
  `panel_hidden` tinyint(1) NOT NULL DEFAULT '0',
  `panel_type` varchar(20) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'A',
  PRIMARY KEY (`panel_id`),
  KEY `panel_type` (`panel_type`,`panel_name`)
) ENGINE=MyISAM AUTO_INCREMENT=78 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fanfiction_panels` WRITE;
/*!40000 ALTER TABLE `fanfiction_panels` DISABLE KEYS */;
INSERT INTO `fanfiction_panels` VALUES (1,'submitted','Submissions','',3,5,0,'A');
INSERT INTO `fanfiction_panels` VALUES (2,'versioncheck','Version Check','',3,7,0,'A');
INSERT INTO `fanfiction_panels` VALUES (3,'newstory','Add New Story','stories.php?action=newstory&admin=1',3,3,0,'A');
INSERT INTO `fanfiction_panels` VALUES (4,'addseries','Add New Series','series.php?action=add',3,3,0,'A');
INSERT INTO `fanfiction_panels` VALUES (5,'news','News','',3,5,0,'A');
INSERT INTO `fanfiction_panels` VALUES (6,'featured','Featured Stories','',3,5,0,'A');
INSERT INTO `fanfiction_panels` VALUES (7,'characters','Characters','',2,2,0,'A');
INSERT INTO `fanfiction_panels` VALUES (8,'ratings','Ratings','',2,3,0,'A');
INSERT INTO `fanfiction_panels` VALUES (9,'members','Members','',2,5,0,'A');
INSERT INTO `fanfiction_panels` VALUES (10,'mailusers','Mail Users','',2,6,0,'A');
INSERT INTO `fanfiction_panels` VALUES (11,'settings','Settings','',1,2,0,'A');
INSERT INTO `fanfiction_panels` VALUES (12,'blocks','Blocks','',1,3,0,'A');
INSERT INTO `fanfiction_panels` VALUES (13,'censor','Censor','',1,0,1,'A');
INSERT INTO `fanfiction_panels` VALUES (14,'admins','Admins','',1,6,0,'A');
INSERT INTO `fanfiction_panels` VALUES (15,'classifications','Classifications','',2,4,0,'A');
INSERT INTO `fanfiction_panels` VALUES (16,'categories','Categories','',2,1,0,'A');
INSERT INTO `fanfiction_panels` VALUES (17,'custpages','Custom Pages','',1,4,0,'A');
INSERT INTO `fanfiction_panels` VALUES (18,'validate','Validate Submission','',3,0,1,'A');
INSERT INTO `fanfiction_panels` VALUES (19,'yesletter','Validation Letter','',3,0,1,'A');
INSERT INTO `fanfiction_panels` VALUES (20,'noletter','Rejection Letter','',3,0,1,'A');
INSERT INTO `fanfiction_panels` VALUES (21,'links','Page Links','',1,5,0,'A');
INSERT INTO `fanfiction_panels` VALUES (22,'messages','Message Settings','',2,0,1,'A');
INSERT INTO `fanfiction_panels` VALUES (23,'login','Login','',0,0,1,'U');
INSERT INTO `fanfiction_panels` VALUES (24,'logout','Logout','',1,5,0,'U');
INSERT INTO `fanfiction_panels` VALUES (25,'revreceived','Reviews Received','',1,0,1,'U');
INSERT INTO `fanfiction_panels` VALUES (26,'editprefs','Edit Preferences','',1,2,0,'U');
INSERT INTO `fanfiction_panels` VALUES (27,'lostpassword','Lost Password','',0,0,1,'U');
INSERT INTO `fanfiction_panels` VALUES (28,'editbio','Edit Bio','',1,1,0,'U');
INSERT INTO `fanfiction_panels` VALUES (29,'register','Register','',0,0,1,'U');
INSERT INTO `fanfiction_panels` VALUES (30,'manageimages','Manage Images','',1,5,0,'S');
INSERT INTO `fanfiction_panels` VALUES (31,'revres','Review Response','',1,0,1,'U');
INSERT INTO `fanfiction_panels` VALUES (32,'stats','View Your Statistics','',1,3,0,'U');
INSERT INTO `fanfiction_panels` VALUES (33,'newstory','Add New Story','stories.php?action=newstory',1,1,0,'S');
INSERT INTO `fanfiction_panels` VALUES (34,'newseries','Add New Series','series.php?action=add',1,3,0,'S');
INSERT INTO `fanfiction_panels` VALUES (35,'managestories','Manage Stories','stories.php?action=viewstories',1,2,0,'S');
INSERT INTO `fanfiction_panels` VALUES (36,'manageseries','Manage Series','series.php?action=manage',1,4,0,'S');
INSERT INTO `fanfiction_panels` VALUES (37,'reviewsby','Your Reviews','',1,0,1,'U');
INSERT INTO `fanfiction_panels` VALUES (38,'storiesby','Stories by {author}','',0,1,0,'P');
INSERT INTO `fanfiction_panels` VALUES (39,'seriesby','Series by {author}','',0,2,0,'P');
INSERT INTO `fanfiction_panels` VALUES (40,'reviewsby','Reviews by {author}','',0,3,0,'P');
INSERT INTO `fanfiction_panels` VALUES (41,'categories','Categories','',0,1,0,'B');
INSERT INTO `fanfiction_panels` VALUES (42,'characters','Characters','',0,2,0,'B');
INSERT INTO `fanfiction_panels` VALUES (43,'ratings','Ratings','',0,3,0,'B');
INSERT INTO `fanfiction_panels` VALUES (44,'titles','Titles','',0,5,0,'B');
INSERT INTO `fanfiction_panels` VALUES (45,'class','Classes','',0,0,1,'B');
INSERT INTO `fanfiction_panels` VALUES (46,'recent','Most Recent','',0,0,1,'B');
INSERT INTO `fanfiction_panels` VALUES (47,'featured','Featured Stories','',0,0,1,'B');
INSERT INTO `fanfiction_panels` VALUES (48,'panels','Panels','',1,1,0,'A');
INSERT INTO `fanfiction_panels` VALUES (49,'phpinfo','PHP Info','',1,7,0,'A');
INSERT INTO `fanfiction_panels` VALUES (50,'contact','Contact','',0,0,1,'P');
INSERT INTO `fanfiction_panels` VALUES (51,'series','Series','',0,4,0,'B');
INSERT INTO `fanfiction_panels` VALUES (52,'viewlog','Action Log','',1,8,0,'A');
INSERT INTO `fanfiction_panels` VALUES (53,'shortstories','10 Shortest Stories','toplists/default.php',0,6,0,'L');
INSERT INTO `fanfiction_panels` VALUES (54,'longstories','10 Longest Stories','toplists/default.php',0,5,0,'L');
INSERT INTO `fanfiction_panels` VALUES (55,'largeseries','10 Largest Series','toplists/default.php',0,1,0,'L');
INSERT INTO `fanfiction_panels` VALUES (56,'smallseries','10 Smallest Series','toplists/default.php',0,2,0,'L');
INSERT INTO `fanfiction_panels` VALUES (57,'reviewedseries','10 Most Reviewed Series','toplists/default.php',0,4,0,'L');
INSERT INTO `fanfiction_panels` VALUES (58,'prolificauthors','10 Most Prolific Authors','toplists/default.php',0,10,0,'L');
INSERT INTO `fanfiction_panels` VALUES (59,'prolificreviewers','10 Most Prolific Reviewers','toplists/default.php',0,12,0,'L');
INSERT INTO `fanfiction_panels` VALUES (60,'reviewedstories','10 Most Reviewed Stories','toplists/default.php',0,8,0,'L');
INSERT INTO `fanfiction_panels` VALUES (61,'readstories','10 Most Read Stories','toplists/default.php',0,9,0,'L');
INSERT INTO `fanfiction_panels` VALUES (62,'manfavs','Manage Favorites','',1,2,0,'F');
INSERT INTO `fanfiction_panels` VALUES (63,'favstories','10 Most Favorite Stories','toplists/default.php',0,7,0,'L');
INSERT INTO `fanfiction_panels` VALUES (64,'favauthors','10 Most Favorite Authors','toplists/default.php',0,11,0,'L');
INSERT INTO `fanfiction_panels` VALUES (65,'favseries','10 Most Favorite Series','toplists/default.php',0,3,0,'L');
INSERT INTO `fanfiction_panels` VALUES (66,'favst','Favorite Stories','',0,0,1,'F');
INSERT INTO `fanfiction_panels` VALUES (67,'favse','Favorite Series','',0,0,1,'F');
INSERT INTO `fanfiction_panels` VALUES (68,'favau','Favorite Authors','',0,0,1,'F');
INSERT INTO `fanfiction_panels` VALUES (69,'favst','Favorite Stories','',0,0,1,'U');
INSERT INTO `fanfiction_panels` VALUES (70,'favse','Favorite Series','',0,0,1,'U');
INSERT INTO `fanfiction_panels` VALUES (71,'favau','Favorite Authors','',0,0,1,'U');
INSERT INTO `fanfiction_panels` VALUES (72,'favlist','{author}\'s Favorites','viewuser.php?action=manfavs',0,5,0,'F');
INSERT INTO `fanfiction_panels` VALUES (73,'skins','Skins','',3,6,0,'A');
INSERT INTO `fanfiction_panels` VALUES (74,'authorfields','Profile Information','',1,9,0,'A');
INSERT INTO `fanfiction_panels` VALUES (75,'maintenance','Archive Maintenance','',1,10,0,'A');
INSERT INTO `fanfiction_panels` VALUES (76,'manual','Admin Manual','',3,6,0,'A');
INSERT INTO `fanfiction_panels` VALUES (77,'modules','Modules','',1,11,0,'A');
/*!40000 ALTER TABLE `fanfiction_panels` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fanfiction_ratings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fanfiction_ratings` (
  `rid` int NOT NULL AUTO_INCREMENT,
  `rating` varchar(60) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `ratingwarning` char(1) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0',
  `warningtext` text COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`rid`),
  KEY `rating` (`rating`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fanfiction_ratings` WRITE;
/*!40000 ALTER TABLE `fanfiction_ratings` DISABLE KEYS */;
INSERT INTO `fanfiction_ratings` VALUES (1,'Everyone','0','');
/*!40000 ALTER TABLE `fanfiction_ratings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fanfiction_reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fanfiction_reviews` (
  `reviewid` int NOT NULL AUTO_INCREMENT,
  `item` int NOT NULL DEFAULT '0',
  `chapid` int NOT NULL DEFAULT '0',
  `reviewer` varchar(60) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0',
  `uid` int NOT NULL DEFAULT '0',
  `review` text COLLATE utf8mb4_general_ci NOT NULL,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `rating` int NOT NULL DEFAULT '0',
  `respond` char(1) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0',
  `type` char(2) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`reviewid`),
  KEY `chapid` (`chapid`),
  KEY `rating` (`rating`),
  KEY `respond` (`respond`),
  KEY `avgrating` (`type`,`item`,`rating`),
  KEY `bychapter` (`chapid`,`rating`),
  KEY `byuid` (`uid`,`item`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fanfiction_reviews` WRITE;
/*!40000 ALTER TABLE `fanfiction_reviews` DISABLE KEYS */;
/*!40000 ALTER TABLE `fanfiction_reviews` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fanfiction_series`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fanfiction_series` (
  `seriesid` int NOT NULL AUTO_INCREMENT,
  `title` varchar(200) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `summary` text COLLATE utf8mb4_general_ci NOT NULL,
  `uid` int NOT NULL DEFAULT '0',
  `isopen` tinyint NOT NULL DEFAULT '0',
  `catid` varchar(200) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0',
  `rating` tinyint NOT NULL DEFAULT '0',
  `classes` varchar(200) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `characters` varchar(250) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `reviews` smallint NOT NULL DEFAULT '0',
  `numstories` int NOT NULL DEFAULT '0',
  `challenges` varchar(200) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`seriesid`),
  KEY `catid` (`catid`),
  KEY `characters` (`characters`),
  KEY `classes` (`classes`),
  KEY `owner` (`uid`,`title`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fanfiction_series` WRITE;
/*!40000 ALTER TABLE `fanfiction_series` DISABLE KEYS */;
/*!40000 ALTER TABLE `fanfiction_series` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fanfiction_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fanfiction_settings` (
  `sitekey` varchar(50) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '1',
  `sitename` varchar(200) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'Your Site',
  `slogan` varchar(200) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'It''s a cool site!',
  `url` varchar(200) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'http://www.yoursite.com',
  `siteemail` varchar(200) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'you@yoursite.com',
  `tableprefix` varchar(50) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `skin` varchar(50) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'default',
  `hiddenskins` varchar(255) COLLATE utf8mb4_general_ci DEFAULT '',
  `language` varchar(10) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'en',
  `submissionsoff` tinyint(1) NOT NULL DEFAULT '0',
  `storiespath` varchar(20) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'stories',
  `store` varchar(5) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'files',
  `autovalidate` tinyint(1) NOT NULL DEFAULT '0',
  `coauthallowed` int NOT NULL DEFAULT '0',
  `maxwords` int NOT NULL DEFAULT '0',
  `minwords` int NOT NULL DEFAULT '0',
  `imageupload` tinyint(1) NOT NULL DEFAULT '0',
  `imageheight` int NOT NULL DEFAULT '200',
  `imagewidth` int NOT NULL DEFAULT '200',
  `roundrobins` tinyint(1) NOT NULL DEFAULT '0',
  `allowseries` tinyint NOT NULL DEFAULT '2',
  `tinyMCE` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_tags` varchar(200) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '<b><i><u><center><hr><p><br /><br><blockquote><ol><ul><li><img><strong><em>',
  `favorites` tinyint(1) NOT NULL DEFAULT '0',
  `multiplecats` tinyint(1) NOT NULL DEFAULT '0',
  `newscomments` tinyint(1) NOT NULL DEFAULT '0',
  `logging` tinyint(1) NOT NULL DEFAULT '0',
  `maintenance` tinyint(1) NOT NULL DEFAULT '0',
  `debug` tinyint(1) NOT NULL DEFAULT '0',
  `captcha` tinyint(1) NOT NULL DEFAULT '0',
  `dateformat` varchar(20) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'd/m/y',
  `timeformat` varchar(20) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '- h:i a',
  `recentdays` tinyint NOT NULL DEFAULT '7',
  `displaycolumns` tinyint(1) NOT NULL DEFAULT '1',
  `itemsperpage` tinyint NOT NULL DEFAULT '25',
  `extendcats` tinyint(1) NOT NULL DEFAULT '0',
  `displayindex` tinyint(1) NOT NULL DEFAULT '0',
  `defaultsort` tinyint(1) NOT NULL DEFAULT '0',
  `displayprofile` tinyint(1) NOT NULL DEFAULT '0',
  `linkstyle` tinyint(1) NOT NULL DEFAULT '0',
  `linkrange` tinyint NOT NULL DEFAULT '5',
  `reviewsallowed` tinyint(1) NOT NULL DEFAULT '0',
  `ratings` tinyint(1) NOT NULL DEFAULT '0',
  `anonreviews` tinyint(1) NOT NULL DEFAULT '0',
  `revdelete` tinyint(1) NOT NULL DEFAULT '0',
  `rateonly` tinyint(1) NOT NULL DEFAULT '0',
  `pwdsetting` tinyint(1) NOT NULL DEFAULT '0',
  `alertson` tinyint(1) NOT NULL DEFAULT '0',
  `disablepopups` tinyint(1) NOT NULL DEFAULT '0',
  `agestatement` tinyint(1) NOT NULL DEFAULT '0',
  `words` text COLLATE utf8mb4_general_ci,
  `version` varchar(10) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '3.5.5',
  `smtp_host` varchar(200) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `smtp_username` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `smtp_password` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`sitekey`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fanfiction_settings` WRITE;
/*!40000 ALTER TABLE `fanfiction_settings` DISABLE KEYS */;
INSERT INTO `fanfiction_settings` VALUES ('fixture355key','Fixture Archive','It\'s a cool site!','http://fixture.local','admin@fixture.local','','default','','en',0,'stories','files',0,0,0,0,0,200,200,0,2,0,'<b><i><u><center><hr><p><br /><br><blockquote><ol><ul><li><img><strong><em>',0,0,0,0,0,0,0,'d/m/y','- h:i a',7,1,25,0,0,0,0,0,5,0,0,0,0,0,0,0,0,0,NULL,'3.5.5',NULL,NULL,NULL);
/*!40000 ALTER TABLE `fanfiction_settings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fanfiction_stats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fanfiction_stats` (
  `sitekey` varchar(50) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0',
  `stories` int NOT NULL DEFAULT '0',
  `chapters` int NOT NULL DEFAULT '0',
  `series` int NOT NULL DEFAULT '0',
  `reviews` int NOT NULL DEFAULT '0',
  `wordcount` int NOT NULL DEFAULT '0',
  `authors` int NOT NULL DEFAULT '0',
  `members` int NOT NULL DEFAULT '0',
  `reviewers` int NOT NULL DEFAULT '0',
  `newestmember` int NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fanfiction_stats` WRITE;
/*!40000 ALTER TABLE `fanfiction_stats` DISABLE KEYS */;
INSERT INTO `fanfiction_stats` VALUES ('fixture355key',0,0,0,0,0,0,0,0,1);
/*!40000 ALTER TABLE `fanfiction_stats` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fanfiction_stories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fanfiction_stories` (
  `sid` int NOT NULL AUTO_INCREMENT,
  `title` varchar(200) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'Untitled',
  `summary` text COLLATE utf8mb4_general_ci,
  `storynotes` text COLLATE utf8mb4_general_ci,
  `catid` varchar(100) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0',
  `classes` varchar(200) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0',
  `charid` varchar(250) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0',
  `rid` varchar(25) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0',
  `date` datetime DEFAULT NULL,
  `updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `uid` int NOT NULL DEFAULT '0',
  `coauthors` varchar(50) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0',
  `featured` char(1) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0',
  `validated` char(1) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0',
  `completed` char(1) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0',
  `rr` char(1) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0',
  `wordcount` int NOT NULL DEFAULT '0',
  `rating` tinyint NOT NULL DEFAULT '0',
  `reviews` smallint NOT NULL DEFAULT '0',
  `count` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`sid`),
  KEY `title` (`title`),
  KEY `catid` (`catid`),
  KEY `charid` (`charid`),
  KEY `rid` (`rid`),
  KEY `uid` (`uid`),
  KEY `featured` (`featured`),
  KEY `completed` (`completed`),
  KEY `rr` (`rr`),
  KEY `validateduid` (`validated`,`uid`),
  KEY `recent` (`updated`,`validated`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fanfiction_stories` WRITE;
/*!40000 ALTER TABLE `fanfiction_stories` DISABLE KEYS */;
INSERT INTO `fanfiction_stories` VALUES (1,'Fixture Story','A preserved fixture story.','','0','0','0','1','2026-10-14 13:43:17','2026-10-14 13:43:17',10,'0','0','1','0','0',8,0,0,0);
INSERT INTO `fanfiction_stories` VALUES (2,'Unvalidated Fixture Story','A story only its author, the coauthor, and admins may read.','','0','0','0','1','2026-10-14 13:43:17','2026-10-14 13:43:17',10,'0','0','0','0','0',8,0,0,0);
/*!40000 ALTER TABLE `fanfiction_stories` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

